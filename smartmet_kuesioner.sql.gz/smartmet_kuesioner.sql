-- MySQL dump 10.13  Distrib 5.7.38, for Linux (x86_64)
--
-- Host: localhost    Database: smartmet_kuesioner
-- ------------------------------------------------------
-- Server version	5.7.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ms_kategori_pertanyaan`
--

DROP TABLE IF EXISTS `ms_kategori_pertanyaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_kategori_pertanyaan` (
  `KategoriID` int(11) NOT NULL AUTO_INCREMENT,
  `Kategori` varchar(64) NOT NULL,
  PRIMARY KEY (`KategoriID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_kategori_pertanyaan`
--

LOCK TABLES `ms_kategori_pertanyaan` WRITE;
/*!40000 ALTER TABLE `ms_kategori_pertanyaan` DISABLE KEYS */;
INSERT INTO `ms_kategori_pertanyaan` (`KategoriID`, `Kategori`) VALUES (1,'Keandalan Produk'),(2,'Harga'),(3,'Pengiriman'),(4,'Service dan Pelayanan');
/*!40000 ALTER TABLE `ms_kategori_pertanyaan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms_kuesioner`
--

DROP TABLE IF EXISTS `ms_kuesioner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_kuesioner` (
  `FormID` varchar(32) NOT NULL,
  `Tanggal` date NOT NULL,
  `NamaPerusahaan` varchar(125) NOT NULL,
  `Alamat` varchar(255) NOT NULL,
  `NoTlp` varchar(32) NOT NULL,
  `Saran` text NOT NULL,
  PRIMARY KEY (`FormID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_kuesioner`
--

LOCK TABLES `ms_kuesioner` WRITE;
/*!40000 ALTER TABLE `ms_kuesioner` DISABLE KEYS */;
/*!40000 ALTER TABLE `ms_kuesioner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms_pakai_produk`
--

DROP TABLE IF EXISTS `ms_pakai_produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_pakai_produk` (
  `FormID` varchar(32) NOT NULL,
  `ProdukID` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_pakai_produk`
--

LOCK TABLES `ms_pakai_produk` WRITE;
/*!40000 ALTER TABLE `ms_pakai_produk` DISABLE KEYS */;
/*!40000 ALTER TABLE `ms_pakai_produk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms_pertanyaan`
--

DROP TABLE IF EXISTS `ms_pertanyaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_pertanyaan` (
  `TanyaID` varchar(32) NOT NULL,
  `Pertanyaan` varchar(125) NOT NULL,
  `Urut` int(11) NOT NULL,
  `KategoriID` int(11) NOT NULL,
  PRIMARY KEY (`TanyaID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_pertanyaan`
--

LOCK TABLES `ms_pertanyaan` WRITE;
/*!40000 ALTER TABLE `ms_pertanyaan` DISABLE KEYS */;
INSERT INTO `ms_pertanyaan` (`TanyaID`, `Pertanyaan`, `Urut`, `KategoriID`) VALUES ('T001','Bagaimana menurut anda mutu produk kami?',1,1),('T002','Bagaimana menurut anda fitur-fitur yang kami tawarkan?',2,1),('T003','Apakah harga yang kami tawarkan sesuai dengan spesifikasi produk kami?',3,2),('T004','Bagaimana menurut anda ketepatan delivery produk kami?',4,3),('T005','Bagaimana service dan pelayanan dari kami ?',5,4);
/*!40000 ALTER TABLE `ms_pertanyaan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms_produk`
--

DROP TABLE IF EXISTS `ms_produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_produk` (
  `ProdukID` varchar(64) NOT NULL,
  `Produk` varchar(64) NOT NULL,
  `Urut` int(11) NOT NULL,
  PRIMARY KEY (`ProdukID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_produk`
--

LOCK TABLES `ms_produk` WRITE;
/*!40000 ALTER TABLE `ms_produk` DISABLE KEYS */;
INSERT INTO `ms_produk` (`ProdukID`, `Produk`, `Urut`) VALUES ('P001','kWh Meter',1),('P002','Segel Plastik Putar',2),('P003','Gas Meter',3);
/*!40000 ALTER TABLE `ms_produk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tr_kuesioner`
--

DROP TABLE IF EXISTS `tr_kuesioner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tr_kuesioner` (
  `FormID` varchar(32) NOT NULL,
  `ProdukID` varchar(32) NOT NULL,
  `TanyaID` varchar(32) NOT NULL,
  `Nilai` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr_kuesioner`
--

LOCK TABLES `tr_kuesioner` WRITE;
/*!40000 ALTER TABLE `tr_kuesioner` DISABLE KEYS */;
/*!40000 ALTER TABLE `tr_kuesioner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'smartmet_kuesioner'
--

--
-- Dumping routines for database 'smartmet_kuesioner'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-12 10:13:58
